
using LHPetVetClinic.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace LHPetVetClinic.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<Cliente> clientes = new List<Cliente>
            {
                new Cliente { Id = 1, Nome = "João Silva", Email = "joao@exemplo.com", Telefone = "123456789", Endereco = "Rua A, 123" },
                new Cliente { Id = 2, Nome = "Maria Souza", Email = "maria@exemplo.com", Telefone = "987654321", Endereco = "Rua B, 456" }
            };

            List<Fornecedor> fornecedores = new List<Fornecedor>
            {
                new Fornecedor { Id = 1, Nome = "Carlos Mendes", Email = "carlos@empresa.com", Telefone = "123123123", Empresa = "Empresa X" },
                new Fornecedor { Id = 2, Nome = "Ana Paula", Email = "ana@empresa.com", Telefone = "321321321", Empresa = "Empresa Y" }
            };

            ViewBag.Clientes = clientes;
            ViewBag.Fornecedores = fornecedores;

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
